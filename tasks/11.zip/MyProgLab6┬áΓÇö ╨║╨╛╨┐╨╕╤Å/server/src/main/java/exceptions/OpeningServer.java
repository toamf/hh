package exceptions;

public class OpeningServer extends Exception{
}