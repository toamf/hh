package exceptions;

public class ConnectionError extends Exception {
}