package commands;

public interface CollectionEditor {
}
