package diagram;

public enum Status {
    OK,
    ASK_OBJECT,
    EXIT,
    ERROR,
    WRONG_ARGUMENTS,
    EXECUTE_SCRIPT
}
