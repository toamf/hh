package exceptions;

/**
 * Класс исключение для рекурсивного исполнения скриптов
 */
public class Recursion extends Exception {
}