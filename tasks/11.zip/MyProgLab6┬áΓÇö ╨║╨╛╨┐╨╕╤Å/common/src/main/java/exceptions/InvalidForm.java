package exceptions;

import java.io.IOException;

public class InvalidForm extends IOException {

}