package exceptions;

import java.io.IOException;

public class CommandRuntimeError extends IOException {

}