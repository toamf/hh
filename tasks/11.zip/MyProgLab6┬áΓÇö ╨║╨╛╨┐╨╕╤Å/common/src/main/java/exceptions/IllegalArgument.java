package exceptions;

import java.io.IOException;

public class IllegalArgument extends IOException {

}