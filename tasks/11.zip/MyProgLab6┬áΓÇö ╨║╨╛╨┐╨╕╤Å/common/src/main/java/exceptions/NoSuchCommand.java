package exceptions;

import java.io.IOException;

public class NoSuchCommand extends IOException {

}