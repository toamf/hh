package models;

/**
 * Проверка на корректность полей
 */
public interface Validatable {
    boolean validate();
}
