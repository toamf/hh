package forms;

public abstract class Form<T> {
    public abstract T build();
}